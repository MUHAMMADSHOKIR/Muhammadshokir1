import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.SwingConstants;

import ashokir.Frame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class shokir_a {

	private JFrame frmShokirRusturant;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					shokir_a window = new shokir_a();
					window.frmShokirRusturant.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public shokir_a() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frmShokirRusturant = new JFrame();
		frmShokirRusturant.setTitle("Shokir Rusturant ");
		frmShokirRusturant.setForeground(Color.BLACK);
		frmShokirRusturant.setBounds(100, 100, 450, 300);
		frmShokirRusturant.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frmShokirRusturant.getContentPane().setLayout(null);
		

		
		String total = "";
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("PLOV");
		chckbxNewCheckBox.setBounds(0, 71, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("SOUP");
		chckbxNewCheckBox_1.setBounds(0, 94, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox_1);
		
		JCheckBox chckbxNewCheckBox_2 = new JCheckBox("SAMSA");
		chckbxNewCheckBox_2.setBounds(0, 117, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox_2);
		
		JLabel lblNewLabel = new JLabel("MEAL MENU");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBackground(Color.ORANGE);
		lblNewLabel.setBounds(142, 10, 134, 32);
		frmShokirRusturant.getContentPane().add(lblNewLabel);
		
		//JLabel lbl3 = new JLabel("New label");
		//lbl3.setBounds(282, 188, 45, 13);
		//frmShokirRusturant.getContentPane().add(lbl3);
		
		
		JLabel lblNewLabel_1 = new JLabel("MEALS");
		lblNewLabel_1.setForeground(Color.GREEN);
		lblNewLabel_1.setBounds(10, 44, 83, 21);
		frmShokirRusturant.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("SALATS ");
		lblNewLabel_2.setForeground(Color.GREEN);
		lblNewLabel_2.setBounds(286, 46, 83, 17);
		frmShokirRusturant.getContentPane().add(lblNewLabel_2);
		
		JCheckBox chckbxNewCheckBox_1_1 = new JCheckBox("Sezor ");
		chckbxNewCheckBox_1_1.setBounds(265, 71, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox_1_1);
		
		JCheckBox chckbxNewCheckBox_1_2 = new JCheckBox("Geen seaweed salad");
		chckbxNewCheckBox_1_2.setBounds(265, 117, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox_1_2);
		
		JCheckBox chckbxNewCheckBox_1_1_1 = new JCheckBox("Olivia ");
		chckbxNewCheckBox_1_1_1.setBounds(265, 94, 93, 21);
		frmShokirRusturant.getContentPane().add(chckbxNewCheckBox_1_1_1);
		
		
		JButton btnNewButton = new JButton("TOTAL PRICE");
		
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (e.getSource() == btnNewButton) {
					if(chckbxNewCheckBox.isSelected()) {
						JLabel lbl4 = new JLabel("Plov");
						lbl4.setBounds(282, 188, 45, 13);
						frmShokirRusturant.getContentPane().add(lbl4);
						System.out.println(lbl4); 
						 System.out.println("   (chckbxNewCheckBox)   Plov    $30.00  ");
						 
						
					}
					else if(chckbxNewCheckBox_1.isSelected()) {
						JLabel lbl5 = new JLabel("Soup");
						System.out.println(lbl5);
						 System.out.println("   (chckbxNewCheckBox_1)   SOUP    $10.00  ");
					}
				else if(chckbxNewCheckBox_2.isSelected()) {
					JLabel lbl6 = new JLabel("SAMSA");
					System.out.println(lbl6);
					 System.out.println("   (chckbxNewCheckBox_2)   SAMSA    $5.00  ");
				}
				else if(chckbxNewCheckBox_1_1.isSelected()) {
					JLabel lbl7 = new JLabel("Soup");
					System.out.println(lbl7);
					 System.out.println("   (chckbxNewCheckBox_1_1)   Sezor    $2.00  ");
				}
				
			        else if(chckbxNewCheckBox_1_1_1.isSelected()) {
					JLabel lbl8 = new JLabel("Soup");
					System.out.println(lbl8);
					 System.out.println("   (chckbxNewCheckBox_1_1_1)   Olivia    $3.00  ");
			        }
					
			        else if(chckbxNewCheckBox_1_2.isSelected()) {
					JLabel lbl9 = new JLabel("Soup");
					System.out.println(lbl9);
					 System.out.println("   (chckbxNewCheckBox_1_2)   Olivia    $3.00  ");
				
			        }
				
			
				}
			}
		});
		btnNewButton.setBounds(142, 184, 85, 21);
		frmShokirRusturant.getContentPane().add(btnNewButton);
		
		
	
	}
	
	         }


