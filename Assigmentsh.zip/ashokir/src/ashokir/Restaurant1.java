package ashokir; 
import javax.swing.*;   
 
import java.awt.Canvas;   
import java.awt.Color;   
import java.awt.Graphics;   
import java.awt.event.*;   
public class Restaurant1 extends JFrame implements ActionListener { 
  JCheckBox f1,f2,f3,f4, d1,d2,d3,d4  ;
     JButton b;   
     JFrame f;   
     JLabel lb1,lb2; 
   
     Restaurant1() {   
                
               f = new JFrame("Muhammadshokir Rusturant "); 
            f1=new JCheckBox("PLOV");   
            f2=new JCheckBox("SOUP");   
            f3=new JCheckBox("SAMSA");   
            f4=new JCheckBox("KEBAB");   
            
              d1=new JCheckBox("SEZOR");   
              d2=new JCheckBox("OLIVIA");   
              d3=new JCheckBox("GREEN SALAT");   
            d4=new JCheckBox("ANDIJAN SALAT");   
             
              b = new JButton("TOTAL");   
               
            lb1= new JLabel("FOODS"); 
            lb2= new JLabel("SALATS"); 
            b.setBackground(Color.GREEN); 
             
             
             
            lb1.setBounds(30,20,150,20);  
            lb2.setBounds(250,20,150,20);  
            f1.setBounds(30,50,150,20);   
            f2.setBounds(30,80,150,20);   
            f3.setBounds(30,110,150,20);   
            f4.setBounds(30,140,150,20);   
              
            d1.setBounds(250,50,150,20);   
            d2.setBounds(250,80,150,20);   
            d3.setBounds(250,110,150,20);   
            d4.setBounds(250,140,150,20);   
           
               
            b.setBounds(155,180,80,30);   
               
              b.addActionListener(this);   
                
              f.add(lb1); f.add(lb2); f.add(b);
              f.add(f1); f.add(f2); f.add(f3); f.add(f4);
              f.add(d1); f.add(d2); f.add(d3); f.add(d4);   
            f.setSize(420,280);   
            f.setLayout(null);   
            f.setVisible(true);   
              setDefaultCloseOperation(EXIT_ON_CLOSE);   
              }   
             
            public void actionPerformed(ActionEvent e){   
              float amount=0;   
            String msg="";   
               
              if(f1.isSelected()){   
               amount+=20;   
               msg="PLOV: $20\n";   
               }   
            if(f2.isSelected()){   
               amount+=15;   
               msg+="SOUP: $15\n";   
             }   
              if(f3.isSelected()){   
                amount+=9;   
              msg+="SAMSA: $9\n";   
               }   
            if(f4.isSelected()){   
                 amount+=16;   
                 msg+="KEBAB: $16\n";   
             }   
            
            if(d1.isSelected()){   
                 amount+=4;   
                 msg+="SEZOR: $4\n";   
             }   
            if(d2.isSelected()){   
                 amount+=4.5;   
                 msg+="OLIVIA: $4.5\n";   
             }   
            if(d3.isSelected()){   
                amount+=6;   
                msg+="GREEN SALAT:$6\n";   
            }   
            if(d4.isSelected()){   
                 amount+=8;   
                 msg+="ANDIJAN SALAT: $8\n";   
             }  
         
           msg+="THANK YOU!\n";   
           JOptionPane.showMessageDialog(this,msg+" Total: $"+ amount); }  
              
           public static void main(String[] args) {  
               new Restaurant1();  
           }   
            


}
